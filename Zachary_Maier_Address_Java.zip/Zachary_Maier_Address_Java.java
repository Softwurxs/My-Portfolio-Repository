class Main {
  public static void main(String[] args) {
      System.out.println("Zachary Maier");
      System.out.println("9300 Munich Drive");
      System.out.println("Parma, Ohio 44130");
  }
}